﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Arius
//{
//    internal interface ILocalFile
//    {
//        string RelativeName { get; }
//        DateTime? CreationTimeUtc { get; }
//        DateTime? LastWriteTimeUtc { get; }
//    }
//}
