﻿using System.Linq;
using System.Windows;
using System.Windows.Markup;

namespace Arius.UI
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
